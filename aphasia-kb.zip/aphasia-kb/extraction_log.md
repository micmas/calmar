# Extraction log

A running, append-only audit log of every agent extraction run and every
human review action. Every entry is one line, pipe-separated, in this
format:

```
<ISO date> | <ACTION> | <citation> | <entry id> | <metadata...>
```

Actions:

- `EXTRACTED` — agent wrote one or more drafts from a paper.
- `APPROVED`  — human moved a draft to the canonical folder.
- `REJECTED`  — human marked a draft as rejected (it stays in `drafts/`
                with `status: rejected` for the audit trail).
- `EDITED`    — human manually edited a canonical entry without going
                through `promote.py` (please add this manually if so).

This log is appended to automatically by `promote.py`. The agent should
add an `EXTRACTED` line for every run.

---

<!-- New entries are appended below this line -->
2026-04-30 | EXTRACTED | @Yourganov2015Predicting | brocas_aphasia, wernickes_aphasia, conduction_aphasia, global_aphasia, anomic_aphasia | 5 drafts (impairment-anchored) | 9 findings | confidence: high (4) / medium (1, Wernicke's small n) | annotator: 20/36 quotes placed (16 missed due to Unicode/line-break artifacts in PDF text extraction) | agent: claude-opus-4-7
2026-05-01 | EXTRACTED | @Alyahya2018NounVerb | phonological_production, semantics, fluency, phonological_recognition, executive_functions, lesion_volume | 6 drafts (5 impairment-anchored PCA-factor drafts + 1 predictor-anchored lesion_volume draft) | 24 findings | confidence: high (all) | flags: many target_ids do not yet exist as canonical region entries (anterior/posterior arcuate, angular gyrus, parietal operculum, posterior supramarginal gyrus, ILF, anterior MTG, temporal pole, superior lateral occipital cortex, precuneus, central opercular cortex, pre-central gyrus, Heschl's gyrus, planum temporale, posterior STG, superior frontal gyrus, paracingulate gyrus, supplementary motor area); method 'VBCM' coded as VLSM throughout (controlled-vocab limitation); fluency findings flagged as lesion-volume-confounded; semantics findings flagged for partial cluster shrinkage under lesion-volume covariate | agent: claude-opus-4-7
2026-05-01 | EXTRACTED | @Barbieri2023 | treatment_of_underlying_forms, typicality_semantic_feature_analysis, spell_study_spell | 3 drafts (therapy-anchored) | 7 findings | confidence: high (all) | flags: target_ids for impairments (agrammatism, anomia, dysgraphia, sentence_comprehension, sentence_production) and right-hemisphere regions (right_anterior_middle_temporal_gyrus, right_anterior_superior_temporal_gyrus) do not yet exist as canonical entries; behavioural-efficacy findings coded as method=clinical_RCT; fMRI-activation findings include enantiomorphic-replacement preprocessing; spell-study-spell f2 has unexpected RH upregulation without behavioral coupling, interpreted post-hoc as phonological-discrimination side effect; sentence-treatment f3 (brain-behavior coupling) is the headline finding linking RH activation change to verb comprehension improvement | agent: claude-opus-4-7
2026-05-01 | RE-EXTRACTED | @Yourganov2015Predicting | brocas_aphasia, conduction_aphasia, wernickes_aphasia, global_aphasia, anomic_aphasia | 5 drafts (impairment-anchored, refresh of 2026-04-30 extraction under v2.4 conventions) | 25 findings (Broca's 7, conduction 3, Wernicke's 7, global 8, anomic 0 null) | confidence: high (Broca's, conduction, global) / medium (Wernicke's, n=7) | conventions applied: hemisphere-prefixed target IDs (left_*); cross-paper cohort-overlap flag pointing to @Fridriksson2018 on every finding (shared USC registry); legacy ho-cort_44 retained for the IFG pars opercularis target since the canonical entry already exists; no per-finding flags about non-existent target IDs (forward-looking convention); anomic_aphasia uses the empty-findings null pattern (paper specifically reports no regions reach Z>1) | annotator: 131/139 quotes placed; 8 missed (line-break artifacts in PDF text) | agent: claude-opus-4-7
2026-05-01 | EXTRACTED | @Fridriksson2018 | form_to_articulation, form_to_meaning | 2 drafts (impairment-anchored; first proper extraction — the canonical regions/ho-cort_44.md previously cited this paper with [PLACEHOLDER] source passages from the worked example) | 12 findings (form_to_articulation 5: pars opercularis, premotor, MFG, anterior SMG, precentral; form_to_meaning 7: posterior MTG, posterior STG, uncinate, posterior SMG, angular, pars orbitalis, anterior MTG) | confidence: high (all) | method: VLSM (the paper's actual analysis is VLSM-then-PCA: 71 univariate VLSMs are stacked into a PCA, where Component 2's positive vs negative loadings define the dual-stream split) | sample n=138 chronic LH stroke patients from USC Aphasia Lab archival database, ≥6 months post-stroke; cohort substantially overlaps with @Yourganov2015Predicting (cohort-overlap flag on every finding) | conventions applied: hemisphere-prefixed target IDs (left_*); legacy ho-cort_44 retained; no per-finding non-existent-target flags; cohort-overlap flag pattern; flag on form_to_articulation:f1 noting that the canonical ho-cort_44.md placeholder source passages should be replaced when promote.py runs | DOI corrected in citations.md (was 10.1073/pnas.1714922115; actual is 10.1073/pnas.1614038114 per the PDF) | agent: claude-opus-4-7
2026-05-05 | AUTO-APPROVED | @Yourganov2015Predicting | brocas_aphasia, global_aphasia | 2 drafts | PDF-quote-match passed (100%) | all hard+soft checks passed | reviewer: auto-reviewer (require-pdf-match)
2026-05-05 | AUTO-APPROVED | @Fridriksson2018 | form_to_articulation, form_to_meaning | 2 drafts | PDF-quote-match passed (100%) | all hard+soft checks passed | reviewer: auto-reviewer (require-pdf-match)
2026-05-05 | AUTO-APPROVED | @Alyahya2018NounVerb | phonological_production, phonological_recognition | 2 drafts | PDF-quote-match passed (100%) | all hard+soft checks passed | reviewer: auto-reviewer (require-pdf-match)
2026-05-05 | AUTO-APPROVED | @Alyahya2018NounVerb | lesion_volume (predictor) | 1 draft | PDF-quote-match passed (100%) | all hard+soft checks passed | reviewer: auto-reviewer (require-pdf-match)
2026-05-05 | AUTO-APPROVED | @Barbieri2023 | spell_study_spell, treatment_of_underlying_forms, typicality_semantic_feature_analysis | 3 drafts | PDF-quote-match passed (100%) | all hard+soft checks passed | reviewer: auto-reviewer (require-pdf-match)
2026-05-06 | AUTO-APPROVED | ? | anomic_aphasia | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Yourganov2015Predicting | conduction_aphasia | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | executive_functions | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | fluency | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | semantics | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Yourganov2015Predicting | wernickes_aphasia | reviewer: michele
2026-05-06 | EXTRACTED | @Saur2008 | left_arcuate_fasciculus_slf, left_extreme_capsule, left_middle_temporal_gyrus, left_superior_temporal_gyrus | 4 drafts (region-anchored) | 6 findings (2 correlational DTI tract-connectivity + 4 fMRI_activation recruitment) | confidence: high (all) | NOTE: healthy volunteers only (n=33, German-speaking), NO aphasia patients — all findings are correlational or recruitment; causal/aphasia inferences are speculative (Discussion only); DTI acquisition parameters in SI Methods not available in main PDF; method: [DTI, fMRI_activation] multimodal; forward-looking target IDs: speech_repetition, auditory_comprehension; key tracts: left AF/SLF (dorsal, STG→premotor) and left extreme capsule (ventral, MTG→vlPFC BA45/47) | agent: claude-sonnet-4-6

2026-05-06 | EXTRACTED | @Fridriksson2018BDNF | tdcs_aphasia_treatment (therapy), bdnf_val66met (predictor) | 2 drafts | 1 finding (therapy: tDCS × BDNF genotype responder RCT) + 1 finding (predictor: BDNF val/val → greater tDCS response) | confidence: high | flags: cohort overlaps with parent RCT (Fridriksson JAMA Neurol 2018); baseline severity difference between BDNF groups becomes non-significant after lesion/time adjustment | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Dresang2022 | bdnf_val66met (predictor) | 1 draft | 3 findings (BDNF main effect on WAB-AQ; BDNF × cortical excitability interaction; BDNF × stimulation-induced neuroplasticity interaction) | confidence: medium | flags: small sample n=17; LASSO-adjusted R² increase minimal for BDNF alone (footnote 1); direction: mixed for cortical-excitability finding (sign reverses by genotype group) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Robson2019 | left_superior_temporal_gyrus_wernickes (region), auditory_temporal_processing (predictor) | 2 drafts | 4 findings (region: WA lesion overlap in left mid-posterior STG/STS; longitudinal comprehension recovery; predictor: 40-Hz FM at 2.5 MPO → 9 MPO comprehension r=−0.94; word phonological discrimination at 5 MPO → 9 MPO comprehension r=0.84) | confidence: medium | flags: no formal voxel-wise LSM (lesion overlap map only); very small df for cross-lagged correlations (df=6 and df=8); paper published in Neurorehabil Neural Repair NOT Brain (citation corrected from prompt) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Baldo2006 | left_ifg_pars_opercularis (letter_fluency, category_fluency) | 1 draft (region-anchored) | 2 findings (f1: letter fluency -> frontal BA44/BA6/BA4; f2: category fluency -> temporal BA22/37/41/42) | confidence: high | flags: uncorrected p<0.05 threshold (no permutation correction); Talairach 2D template lesion tracing; mixed MRI/CT; no MNI coordinates reported | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Bonilha2014 | left_ifg_pars_triangularis (naming, fluency, auditory_comprehension via BA45/BA22 disconnection) | 1 draft (region-anchored) | 3 findings (f1: BA45 disconnection->naming beta=1.21 p<0.001; f2: BA45 disconnection->fluency beta=7.52 p=0.025; f3: BA22 disconnection->comprehension p=0.01) | confidence: high (f1,f2) / medium (f3: beta value suspect OCR artifact) | flags: cohort overlaps @Fridriksson2018Anatomy (same USC/MUSC lab); DTI params in Online Supplement only; disconnection beta for BA22 (f3) printed as '47' in author manuscript (likely 0.47); reference_space not stated in main text | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Fridriksson2018Anatomy | left_ifg_pars_opercularis (speech_fluency, aphasia_quotient), left_posterior_stg (sentence_comprehension, auditory_word_recognition, naming) | 2 drafts (region-anchored) | 5 findings (IFG opercularis f1: speech fluency R2=0.40 multivariate RLSM; f2: AQ CLSM hub; posterior STG f1: sentence comprehension R2=0.60; f2: auditory word recognition R2=0.31; f3: naming network RLSM+CLSM) | confidence: high (all) | flags: cohort overlaps @Fridriksson2018 (same USC Aphasia Lab archival database; n=138 vs n=159); n varies per test (sentence comprehension n=57, PNT n=105, full n=159); method coded as LSM (RLSM arm) — CLSM arm coded as disconnectome in imaging_details notes; PCA-derived component maps not separately extracted (would require additional drafts for speech production/comprehension components) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @MassonTrottier2021 | phonological_component_analysis (therapy) | 1 draft (therapy-anchored) | 2 findings (f1: increased LH visual-semantic rsFC ant. temporal fusiform bilateral SCC and SCC ant. ITG, relationship: treatment_response; f2: decreased RH rsFC lingual gyrus SFG, relationship: treatment_response) | confidence: high | annotation: 9/9 (100%) | agent: claude-sonnet-4-6
2026-05-06 | REFUSED | @Radanovic2017 | 1-s2.0-S0093934X16301717-main.pdf | reason: Comprehensive narrative review of aphasia in basal ganglia vascular lesions — no primary dataset; secondary synthesis of published case reports and studies.
2026-05-06 | REFUSED | @NadeauCrosson1997 | 1-s2.0-S0093934X97917077-main.pdf | reason: 48-page critical review of subcortical aphasia literature — no primary patient cohort; purely secondary synthesis.
2026-05-06 | REFUSED | @Crosson1999 | 1-s2.0-S0278262699910886-main.pdf | reason: Review of four previously-published thalamic lesion cases — secondary re-analysis of own published data; no new primary dataset.
2026-05-06 | REFUSED | @Wallentin | file.pdf | reason: Meta-analysis and database query on sex differences in post-stroke aphasia rates — no primary patient cohort; aggregate statistical synthesis only.
2026-05-06 | FLAGGED | UNKNOWN | 1-s2.0-S0093934X84710637-main.pdf | reason: Scanned PDF — no extractable text; OCR required before extraction can proceed. Paper appears to be a 1984 Brain and Language article (15 pages). User action needed.
2026-05-06 | FLAGGED | @Pflugshaupt2009 | awp141.pdf | reason: Pure alexia paper (visual field defects in pure alexia) — may be outside KB scope (aphasia vs. reading disorders). User decision needed on whether to include.
2026-05-06 | EXTRACTED | @Harvey2022 | lesion_volume (predictor) | 1 draft (predictor-anchored; 2 findings) | f1: smaller lesion volume → greater long-term WAB-R AQ gain [R2=0.52 F(4,13)=3.51 p=.037]; f2: ALA participation satisfaction → better long-term outcome [combined model R2=0.68 p=.003] | confidence: high (f1) medium (f2) | annotation: 8/8 (100%) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Breining2022 | left_angular_gyrus (region) | 1 draft (region-anchored) | 2 findings (f1: left AG → object naming LASSO=-0.524 p<.001; f2: left AG → action naming LASSO=-0.405 p=.728 in model not independent) | PPA EXCLUDED (non-stroke etiology documented in provenance.flags) | confidence: high | annotation: 8/8 (100%) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Kristinsson2025 | severity_metric (predictor; WAB-R subtest scores) | 1 draft (predictor-anchored) | 2 findings (f1: shared left perisylvian network R2=0.22–0.25 across WAB-R subtests, best DTI r=0.45 auditory comprehension; f2: right putamen uniquely predicts naming/repetition p=0.013/0.021, left STL+right precuneus predict comprehension p=0.049/0.045) | confidence: high (f1) medium (f2: post-hoc exploratory) | annotation: 14/14 (100%) | flags: POLAR trial (NCT03416738) USC/MUSC cohort overlaps @Fridriksson2018, @Yourganov2015Predicting | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Teghipco2024 | severity_metric (predictor; imaging_metric; WAB-AQ binary severe vs non-severe) | 1 draft (predictor-anchored) | 2 findings (f1: 3D CNN balanced accuracy=0.77 F1=0.70 outperforms SVM t(19)=-10 p=5.26e-9 Cohen's d=2.24; f2: right hemisphere morphometry significantly more salient for severe predictions vs left hemisphere for non-severe p<0.0001 all ROIs) | confidence: high | annotation: 14/14 (100%) | flags: cohort overlaps @Fridriksson2018, @Yourganov2015Predicting, @Kristinsson2025 (same USC/MUSC Aphasia Lab, n=231) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @White2024 | severity_metric (predictor; clinical; CAT spoken picture description aphasic vs non-aphasic) | 1 draft (predictor-anchored) | 2 findings (f1: tabular logistic regression balanced accuracy=0.813; f2: ResNet-18 Hybrid ROI CNN balanced accuracy ~0.85, FDR-corrected significant improvement over baseline) | confidence: high | annotation: 11/11 (100%) | flags: PLORAS cohort (UCL, n=758) distinct from USC/MUSC and BU cohorts — no overlap | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Hu2025 | severity_metric (predictor; behavioural; WAB-R AQ continuous) | 1 draft (predictor-anchored) | 2 findings (f1: multimodal SVR DM+PSW+rsFMRI-FC r=0.73 RMSE=15.82 outperforms single-modality; f2: rsFMRI-FC SHAP=3.65 highest predictor class; left arcuate posterior + fronto-insular tract selected 11/11 folds) | confidence: high | annotation: 13/13 (100%) | flags: Boston University CBR (Kiran lab, n=76) distinct from USC/MUSC and PLORAS cohorts; pipeline mismatch Cohort 1 vs 2 for lesion segmentation and DTI | agent: claude-sonnet-4-6
2026-05-06 | REFUSED | @Mohr2017 | Mohr-2017-Neuroplasticity and Functional Recov.pdf | reason: Opinion/perspective article — no primary patient data, no original lesion-symptom or neuroimaging dataset; only narrative argument and secondary citations.
2026-05-06 | REFUSED | @Raymer | Raymer-Effectiveness of Constraint-Induced Lan.pdf | reason: Systematic review / meta-analysis of CILT studies — no primary dataset; summary statistics only across heterogeneous studies, not extractable as individual findings.
2026-05-06 | REFUSED | @Shekari2022 | Shekari-2022-Mechanisms of brain activation fo.pdf | reason: Narrative systematic review of fMRI activation studies in aphasia therapy — no primary patient cohort; secondary synthesis only.
2026-05-06 | REFUSED | @Simic2023 | Simic-2023-Treatment-induced neuroplasticity a.pdf | reason: Systematic review of treatment-induced neuroplasticity in aphasia — no original dataset; purely a synthesis of published studies.
2026-05-06 | REFUSED | @Watila2015 | Watila-2015-Factors predicting post-stroke aph.pdf | reason: Narrative review of prognostic factors for post-stroke aphasia — no primary data; secondary synthesis.
2026-05-06 | REFUSED | @MirmanThye2018 | mirman-thye-2018-uncovering-the-neuroanatomy-of-core-language-systems-using-lesion-symptom-mapping.pdf | reason: Current Directions in Psychological Science review article — reinterprets previously published LSM data; no new primary dataset extractable.
2026-05-06 | EXTRACTED | @Stefaniak2022 | bilateral_middle_frontal_gyrus_recovery (region; 4 findings) | f1: bilateral MFG + right temporo-occipital MTG activation increase → fluency recovery (beta=0.29-0.30 pre-control, beta=0.38 post-control); f2: bilateral ATL activation decrease → semantic/executive recovery (only with baseline control; false-negative otherwise); f3: bilateral precentral/vmPFC/precuneus decrease → phonology recovery (moderated by baseline severity); f4: right SMG/insula/MTG at T1 cross-sectionally associated with fluency (beta=0.54 P=7.1e-5) | longitudinal fMRI, n=26 left-hemisphere stroke, 2wks→4mths | annotation: 14/15 (93%); 1 missed (method quote p.3 — SPM paragraph variant) | confidence: high (f1,f2,f4) medium (f3: PC3 did not significantly improve) | flags: dataset previously reported in Geranmayeh 2016/2017; key methodological contribution: proportional-recovery confound control via T1 PC score revealed false-negatives (bilateral ATL for semantic/executive) and validated true positives | agent: claude-sonnet-4-6
2026-05-06 | REFUSED | @Brady2022RELEASE | 3040338.pdf | reason: Systematic review and individual participant data network meta-analysis (PROSPERO CRD42018110947) — no primary patient dataset collected by authors; synthesis of 174 datasets from 28 countries (n=5928 IPD); method is meta-analytic not primary.
2026-05-06 | REFUSED | @Wilson2021 | Wilson-2021-Neuroplasticity in post-stroke ap1.pdf | reason: Systematic review and meta-analysis (PROSPERO CRD42018116295) of 86 fMRI/PET studies of neuroplasticity in post-stroke aphasia — no primary patient data; secondary synthesis with methodological appraisal only.
2026-05-06 | AUTO-APPROVED | @Yourganov2015Predicting | brocas_aphasia | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Fridriksson2018 | form_to_articulation | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Fridriksson2018 | form_to_meaning | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Yourganov2015Predicting | global_aphasia | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | phonological_production | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | phonological_recognition | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Fridriksson2018BDNF | bdnf_val66met | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | lesion_volume | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Hu2025 | severity_metric | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Teghipco2024 | severity_metric | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @White2024 | severity_metric | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_anterior_temporal_lobe | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Fridriksson2018Anatomy | left_ifg_pars_opercularis | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_middle_temporal_gyrus | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_superior_temporal_gyrus | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Barbieri2023 | spell_study_spell | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Fridriksson2018BDNF | tdcs_aphasia_treatment | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Barbieri2023 | treatment_of_underlying_forms | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Barbieri2023 | typicality_semantic_feature_analysis | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Robson2019 | auditory_temporal_processing | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Dresang2022 | bdnf_val66met | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Marchina2011 | left_arcuate_fasciculus | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_arcuate_fasciculus_slf | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_extreme_capsule | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_frontal_white_matter_bottleneck | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Fridriksson2018Anatomy | left_posterior_stg | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_superior_temporal_gyrus_wernicke | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_supramarginal_gyrus_premotor | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @MassonTrottier2021 | phonological_component_analysis | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Robson2019 | auditory_temporal_processing | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Dresang2022 | bdnf_val66met | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Harvey2022 | lesion_volume | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Kristinsson2025 | severity_metric | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Stefaniak2022 | bilateral_middle_frontal_gyrus_recovery | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Breining2022 | left_angular_gyrus | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Marchina2011 | left_arcuate_fasciculus | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_arcuate_fasciculus_slf | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_extreme_capsule | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_frontal_white_matter_bottleneck | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Baldo2006 | left_ifg_pars_opercularis | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Bonilha2014 | left_ifg_pars_triangularis | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Bonilha2014 | left_posterior_stg | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Fridriksson2018Anatomy | left_posterior_stg | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_superior_temporal_gyrus_wernicke | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Robson2019 | left_superior_temporal_gyrus_wernickes | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_supramarginal_gyrus_premotor | reviewer: michele
2026-05-06 | AUTO-APPROVED | @MassonTrottier2021 | phonological_component_analysis | reviewer: michele
2026-05-06 | EXTRACTED | @Dronkers1996 | left_precentral_gyrus_insula | Lesion-overlap double dissociation: left precentral gyrus of insula necessary for apraxia of speech (n=44, 25 AoS vs 19 controls); 100% overlap in AoS group, 0% in controls; Talairach -41,-2,10 | annotation: 8/8 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Lazar2010 | initial_aphasia_severity | Initial WAB composite (WABinitial, 0-30) predicts 81% of variance in 90-day aphasia change (R2=0.81, p<0.001); proportional recovery 0.73 of maximal potential regardless of therapy (n=21, mild-moderate aphasia) | annotation: 7/7 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Pedersen2004 | stroke_severity_sss | Initial WAB-AQ + modified SSS predict R2=0.60 of 1-year WAB-AQ; WAB-AQ alone R2=0.47; age, sex, aphasia type not significant (n=203 first-ever stroke, Copenhagen Aphasia Study) | annotation: 12/12 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Leff2009 | left_superior_temporal_gyrus__Leff2009 | n=210 UCL stroke cohort; VBM (VBCM) identifies left posterior STG/STS [-66,-32,4] as shared substrate for auditory STM (digit span) and spoken sentence comprehension; 2 findings | annotation: 8/9 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @DenOuden2019 | syntactic_processing (impairment) | n=71 LH stroke (68 LSM); VLSM+CLSM; 3 findings: f1 left IFG pars triangularis (BA45) → morphosyntactic production deficit (causal, VLSM, lesion-size controlled); f2 left pSTG/angular gyrus → verb argument structure production deficit (causal, VLSM, k=47); f3 ventral IFG-temporal connectivity → noncanonical sentence production (correlational, CLSM, not lesion-size corrected) | COHORT_OVERLAP: USC/MUSC; overlaps @Fridriksson2018 @Yourganov2015Predicting @Basilakos2015 | annotation: 11/11 (100%) | schema: 0 issues | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Basilakos2015 | left_precentral_gyrus (region) | n=43 chronic LH stroke, USC cohort; VLSM (continuous T1-signal); 2 findings: f1 left precentral/postcentral gyrus → AOS-specific errors (causal, 2508 voxels); f2 left temporal/inferior prefrontal → aphasia-related speech errors (causal, dissociated from AOS) | Refutes Dronkers (1996) insula localization; no insula prediction of AOS | COHORT_OVERLAP: USC/MUSC | annotation: 8/8 (100%) | schema: 0 issues | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Itabashi2015 | left_precentral_gyrus (region) | n=136 acute/subacute LH MCA stroke (Kohnan Hospital, Japan); VLSM (Liebermeister); 2 findings: f1 left precentral gyrus posterior wall → pure AOS (causal, Z_max=3.482); f2 basal ganglia/corona radiata/precentral → AOS+aphasia (causal, larger lesion burden) | Independent replication of @Basilakos2015 in acute Japanese cohort | NO cohort overlap with USC papers | annotation: 8/8 (100%) | schema: 0 issues | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Robson2014 | left_anterior_temporal_lobe__Robson2014 | n=12 chronic Wernicke's aphasia; distortion-corrected fMRI reveals left ATL overactivation (anterior fusiform, temporal pole) + right aSTG for written words as residual comprehension substrate; 2 findings | annotation: 5/9 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Naeser2005 | tms_right_ifg__Naeser2005 | n=4 open-protocol; 1Hz rTMS to right pars triangularis (BA45) for 10 days; significant BNT improvement at 2mo (p=0.003) lasting at 8mo in 3/4; 1 finding | annotation: 3/6 | agent: claude-sonnet-4-6
2026-05-06 | AUTO-APPROVED | @Lazar2010 | initial_aphasia_severity | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Dronkers1996 | left_precentral_gyrus_insula | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Basilakos2015 | left_precentral_gyrus | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @DenOuden2019 | syntactic_processing | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Pedersen2004 | stroke_severity_sss | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Robson2014 | left_anterior_temporal_lobe | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Itabashi2015 | left_precentral_gyrus | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Leff2009 | left_superior_temporal_gyrus | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Naeser2005 | tms_right_ifg__Naeser2005 | reviewer: claude-cowork
2026-05-07 | EXTRACTED_REVIEW | @Raymer | constraint_induced_language_therapy | 3 findings | annotation: 9/9 | agent: claude-sonnet-4-6
2026-05-07 | EXTRACTED_REVIEW | @Shekari2022 | aphasia_therapy_neuroplasticity_fmri | 3 findings | annotation: 9/9 | agent: claude-sonnet-4-6
2026-05-07 | EXTRACTED_REVIEW | @Simic2023 | treatment_neuroplasticity_aphasia | 3 findings | annotation: 9/9 | agent: claude-sonnet-4-6
2026-05-07 | EXTRACTED_REVIEW | @Watila2015 | aphasia_prognosis_predictors | 3 findings | annotation: 9/9 | agent: claude-sonnet-4-6
2026-05-07 | EXTRACTED_REVIEW | @Wilson2021 | neuroplasticity_poststroke_aphasia | 4 findings | annotation: 12/12 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED_REVIEW | @NadeauCrosson1997 | subcortical_aphasia | 4 findings | annotation: 12/12 | agent: claude-sonnet-4-6
2026-05-06 | RE-EXTRACTED_AS_REVIEW | @NadeauCrosson1997 | previously REFUSED 2026-05-06; re-extracted under schema v2.4 narrative_review conventions; draft: drafts/reviews/subcortical_aphasia__NadeauCrosson1997.md
2026-05-06 | EXTRACTED_REVIEW | @Radanovic2017 | basal_ganglia_aphasia | 4 findings | annotation: 9/9 | agent: claude-sonnet-4-6
2026-05-06 | RE-EXTRACTED_AS_REVIEW | @Radanovic2017 | previously REFUSED 2026-05-06; re-extracted under schema v2.4 narrative_review conventions; draft: drafts/reviews/basal_ganglia_aphasia__Radanovic2017.md
2026-05-06 | EXTRACTED_REVIEW | @Crosson1999 | thalamic_language_mechanisms | 3 findings | annotation: 8/8 | agent: claude-sonnet-4-6
2026-05-06 | RE-EXTRACTED_AS_REVIEW | @Crosson1999 | previously REFUSED 2026-05-06; re-extracted under schema v2.4 narrative_review conventions; draft: drafts/reviews/thalamic_language_mechanisms__Crosson1999.md
2026-05-06 | EXTRACTED_REVIEW | @MirmanThye2018 | lsm_language_systems_review | 4 findings | annotation: 11/11 | agent: claude-sonnet-4-6
2026-05-07 | IDENTIFIED-VIA-OCR | @Goldenberg1994 | 1-s2.0-S0093934X84710637-main.pdf -> Goldenberg1994.pdf | OCR via tesseract 4.1.1 + ocrmypdf 16.13.0 (4 pages, ~10s, 100% text recovery on title page). Resolves the 2026-05-06 FLAGGED entry. Paper: Goldenberg G, Spatt J. (1994). Influence of size and site of cerebral lesions on spontaneous recovery of aphasia and on success of language therapy. Brain Lang 47(4):684-698. doi:10.1006/brln.1994.1067. Filename's "84" is an Elsevier internal sequence, NOT the year. Searchable PDF (image+invisible OCR layer, PDF/A-2b) saved at papers/Goldenberg1994.pdf. Citation added to citations.md as [cited] (referenced as primary in drafts/reviews/aphasia_prognosis_predictors__Watila2015.md). Original publisher-named PDF could not be deleted from sandbox due to ACL — user can rm on their Mac.
2026-05-07 | APPROVED | @DenOuden2019 | syntactic_processing | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | APPROVED | @Pedersen2004 | stroke_severity_sss | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | APPROVED | @Robson2014 | left_anterior_temporal_lobe__Robson2014 | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | APPROVED | @Itabashi2015 | left_precentral_gyrus | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | APPROVED | @Leff2009 | left_superior_temporal_gyrus__Leff2009 | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | APPROVED | @Naeser2005 | tms_right_ifg__Naeser2005 | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | AUTO-APPROVED | @Goldenberg1994 | lesion_volume__Goldenberg1994 | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | AUTO-APPROVED | @Goldenberg1994 | left_temporobasal__Goldenberg1994 | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | AUTO-APPROVED | @Watila2015 | aphasia_prognosis_predictors__Watila2015 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Shekari2022 | aphasia_therapy_neuroplasticity_fmri__Shekari2022 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Radanovic2017 | basal_ganglia_aphasia__Radanovic2017 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Raymer | constraint_induced_language_therapy__Raymer | reviewer: michele
2026-05-07 | AUTO-APPROVED | @MirmanThye2018 | lsm_language_systems_review__MirmanThye2018 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Wilson2021 | neuroplasticity_poststroke_aphasia__Wilson2021 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @NadeauCrosson1997 | subcortical_aphasia__NadeauCrosson1997 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Crosson1999 | thalamic_language_mechanisms__Crosson1999 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Simic2023 | treatment_neuroplasticity_aphasia__Simic2023 | reviewer: michele
